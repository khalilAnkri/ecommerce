# Setup guide: run Poilu & Co with XAMPP (Windows)

## 1. Start XAMPP
1. Open the **XAMPP Control Panel** (run it as administrator the first time).
2. Click **Start** next to **Apache** and next to **MySQL**. Both should turn green.
   - If Apache won't start, port 80 is usually taken by Skype, IIS or another program. Close that program, or go to *Config → Apache (httpd.conf)*, change `Listen 80` to `Listen 8080`, and then use `http://localhost:8080/...` in every URL below.
   - If MySQL won't start, port 3306 is taken, usually by another MySQL install. Stop that service in Windows *Services*.

## 2. Put the project in htdocs
1. Unzip the project.
2. Copy the folder `poilu-and-co` into `C:\xampp\htdocs\`.
   You should end up with `C:\xampp\htdocs\poilu-and-co\index.php`.
   (If you keep the name `ecommerce` from GitHub, replace `poilu-and-co` with `ecommerce` in the URLs.)

## 3. Create the database
1. Open `http://localhost/phpmyadmin` in your browser.
2. Click the **Import** tab at the top. Do not select a database first.
3. Click *Choose file*, pick `poilu-and-co\database\database.sql`, then click **Import** (or **Go**) at the bottom.
4. On the left you should now see the database `group2` with 7 tables.
   Importing the file again resets all the data, which is handy before the presentation.

## 4. Check the connection settings
Open `includes\db.php`. The defaults match XAMPP (`root` user, empty password):
```php
$db_host = 'localhost';
$db_name = 'group2';
$db_user = 'root';
$db_pass = '';
```

## 5. Open the website
`http://localhost/poilu-and-co/`

| Test | Username | Password |
|---|---|---|
| Customer | `client` | `Client123!` |
| Admin | `admin` | `Admin123!` |

## 5b. Apriori ("Fréquemment achetés ensemble")
The website already shows the result (`analytics/output/apriori_rules.json` is in the repo).
To run the analysis yourself:
1. Install **Python 3.10+** from https://www.python.org (tick **"Add python.exe to PATH"**), and the VS Code extensions **Python** and **Jupyter**.
2. In a terminal opened in the project folder: `pip install -r requirements.txt` (file at the root of the project)
3. With MySQL started: `python analytics/apriori_analysis.py`, or open `analytics/Apriori_e_commerce.ipynb` in VS Code and click **Run All**.

## 5c. Test the site against the assignment
See `_tests/README.md`: `python _tests/test_assignment.py` (automatic) + a manual checklist.

## 6. Teacher requirement: the database must be called `groupX`
We are group 2, so the database is `group2`: it is set in `database\database.sql` (`CREATE DATABASE` and `USE`), in `includes\db.php` (`$db_name`) and in `analytics\apriori_analysis.py` (`DB_NAME`).
If you imported the old `poilu_and_co` database before, import `database.sql` again (you can then delete `poilu_and_co` in phpMyAdmin).

## Troubleshooting
| Problem | Fix |
|---|---|
| "La base de données n'est pas connectée" | MySQL isn't started in XAMPP, or the name in `db.php` doesn't match the database name. |
| Blank page | Look at `C:\xampp\apache\logs\error.log`. |
| "Trop de tentatives" while testing login | Wait 15 minutes, or in phpMyAdmin run `DELETE FROM login_attempts;`. |
| Page without CSS | Check that you opened it through `http://localhost/...`, not by double-clicking the file. |

## Optional: work on the code
- **VS Code** with the *PHP Intelephense* extension.
- **Git**: `git pull` to get your teammates' work, then copy or clone the repo straight into `htdocs` so you don't have to copy files by hand.
